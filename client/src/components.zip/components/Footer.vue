<template>
  <footer class="footer-distributed">
    <div class="footer-left">
      <p class="footer-links"></p>
      <p class="footer-company-name">WECARE4YOU &copy; 2021</p>
    </div>

    <div class="footer-center">
      <div>
        <i class="fa fa-map-marker"></i>
        <p><span>21 Revolution Street</span> Malmö, Sweden</p>
        <p>phone: 070449303</p>
      </div>

      <div>
        <i class="fa fa-phone"></i>
        <p>email: WECARE4YOU.com</p>
      </div>
    </div>
  </footer>
</template>

<style>
footer {
  margin-top: 200px;
  border: white;
  background: #172531;
  color: aliceblue;
  height: 25%;
  font-family: 'Trebuchet MS', Helvetica, sans-serif;
  font-size: 14px;
  letter-spacing: -1px;
  word-spacing: -0.6px;
  font-weight: 400;
  text-decoration: none;
  font-style: normal;
  font-variant: small-caps;
  text-transform: uppercase;
  text-align: center;
}
</style>
